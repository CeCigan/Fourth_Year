-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Ноя 08 2023 г., 12:54
-- Версия сервера: 8.0.30
-- Версия PHP: 8.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `music-house`
--

-- --------------------------------------------------------

--
-- Структура таблицы `catalog`
--

CREATE TABLE `catalog` (
  `id` int NOT NULL,
  `img` longtext NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` double NOT NULL,
  `year` int NOT NULL,
  `country` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `count` int NOT NULL,
  `created_at` date NOT NULL,
  `updated_at` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `catalog`
--

INSERT INTO `catalog` (`id`, `img`, `name`, `price`, `year`, `country`, `type`, `count`, `created_at`, `updated_at`) VALUES
(1, '/media/images/guitar1.jpeg', 'Yamaha-3253', 10000, 1999, 'USA', 'guitar', 100, '2023-10-14', '2023-10-14'),
(2, '/media/images/guitar2.jpeg', 'Marshall-3245', 15000, 2005, 'Mexico', 'guitar', 10, '2023-10-11', '2023-10-11'),
(3, '/media/images/string1.jpeg', 'Vivaldi-str234', 30000, 2010, 'Italia', 'string', 11, '2023-10-03', '2023-10-03'),
(4, '/media/images/synth4.png', 'Hohland-85693', 30000, 2012, 'Germany', 'synth', 14, '2023-10-11', '2023-10-11'),
(5, '/media/images/guitar3.jpeg', 'Federico-3651', 20000, 2010, 'Italia', 'guitar', 10, '2023-10-02', '2023-10-02'),
(6, '/media/images/string2.jpeg', 'Lolita-351', 50000, 2015, 'Mexico', 'string', 9, '2023-10-13', '2023-10-13'),
(7, '/media/images/synth2.jpeg', 'graphica-3125', 15000, 2020, 'USA', 'synth', 5, '2023-10-17', '2023-10-17'),
(8, '/media/images/synth3.jpeg', 'Roland-9533', 30000, 2021, 'USA', 'synth', 5, '2023-10-10', '2023-10-10');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `surname` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `patronymic` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `login` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `role` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `name`, `surname`, `patronymic`, `login`, `email`, `password`, `role`) VALUES
(1, 'Максим', 'Сельков', 'Сергеевич', 'admin', 'abdurachman.5@mail.ru', '81dc9bdb52d04dc20036dbd8313ed055', 1),
(2, 'Иван', 'Иванов', 'Иванович', 'Ivanov', 'Ivanov@mail.ru', '81dc9bdb52d04dc20036dbd8313ed055', 0),
(3, 'Пётр', 'Петров', 'Петрович', 'Petrov', 'Petrov@mail.ru', '81dc9bdb52d04dc20036dbd8313ed055', 0),
(4, 'Сергей', 'Попов', 'Владимирович', 'Popov', 'Popov@yandex.ru', '81dc9bdb52d04dc20036dbd8313ed055', 0),
(5, 'Самокат', 'Велосипедов', 'Петрович', 'Velosiped135', 'Velosipedov@mail.ru', '81dc9bdb52d04dc20036dbd8313ed055', 0),
(6, 'fdhdfh', 'dhdf', 'dfhdfh', 'dgdg', 'dfh@mail.ru', '81dc9bdb52d04dc20036dbd8313ed055', 0);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `catalog`
--
ALTER TABLE `catalog`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `catalog`
--
ALTER TABLE `catalog`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
