<?php
require('php/header.php');
?>
<main>
  <h2>Новинки компании</h2>
  <div class="slider-container">
    <div class="slider">
      <div class="slide">
        <img src="./media/images/guitar1.jpeg" alt="Гитара Yamaha-3253" />
        <p>Yamaha-3253</p>
      </div>
      <div class="slide">
        <img src="./media/images/synth3.jpeg" alt="Синтезатор Sony-8532" />
        <p>Sony-8532</p>
      </div>
      <div class="slide">
        <img src="./media/images/synth4.png" alt="Синтезатор Holand" />
        <p>Holand-85693</p>
      </div>
      <div class="slide">
        <img src="./media/images/guitar4.jpeg" alt="Гитара Fender-Stratocaster" />
        <p>Fender-Stratocaster</p>
      </div>
      <div class="slide">
        <img src="./media/images/guitar5.jpeg" alt="Гитара Marshall-Acoustic" />
        <p>Marshall-Acoustic</p>
      </div>
      <button class="prev-button" aria-label="Посмотреть предыдущий слайд">
        &lt;
      </button>
      <button class="next-button" aria-label="Посмотреть следующий слайд">
        &gt
      </button>
    </div>
  </div>
</main>

<?php
require('php/footer.php');
?>

<script src="./scripts/slider.js"></script>
</body>

</html>