<?php
require('../php/header.php');
require('../php/connect.php');
?>
<main>
    <h2>Регистрация</h2>
    <div class="container reg-form">
        <form action="../php/registration.php" method="POST">
            <input type="text" name="surname" placeholder="Фамилия" required class="inp">
            <input type="text" name="name" placeholder="Имя" required class="inp">
            <input type="text" name="patronymic" placeholder="Отчество" required class="inp">
            <input type="email" name="email" placeholder="Почта" required class="inp">
            <input type="text" name="login" placeholder="Логин" required class="inp">
            <input type="password" name="password" placeholder="Пароль" required class="inp">
            <input type="password" name="repeat_password" placeholder="Повторите пароль" required class="inp">
            <p><input type="checkbox">Согласен с <a href="">правилами</a></p>
            <input type="submit" value="Зарегистрироваться" class="btn">
        </form>
    </div>

</main>
<?php
require('../php/footer.php');
?>
</body>

</html>