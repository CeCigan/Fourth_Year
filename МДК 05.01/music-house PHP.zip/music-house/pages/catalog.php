<?php
require('../php/header.php');
require('../php/connect.php');
  ?>
<main>
  <h2>Каталог</h2>
  <div class="filter">
    <div class="filter__items">
      <h5>Сортировка:</h5>
      <button id="sortStandart" class="btn sort">По умолчанию</button>
      <button id="sortYear" class="btn sort">По году производства</button>
      <button id="sortName" class="btn sort">По наименованию</button>
      <button id="sortPrice" class="btn sort">По цене</button>
    </div>
    <div class="filter__items">
      <h5>Фильтрация:</h5>
      <button id="all" class="btn filt">Все</button>
      <button id="guitar" class="btn filt">Струнные</button>
      <button id="string" class="btn filt">Смычковые</button>
      <button id="synth" class="btn filt">Клавишные</button>
    </div>
  </div>
  <div class="catalog">
    <?php
    $result = $mysqli->query("SELECT * FROM `catalog`"); // запрос на выборку
    while ($row = $result->fetch_assoc()) // получаем все строки в цикле по одной
    {
      echo
        '
          <div class="catalog__item ' . $row['type'] . '"
              data-name="' . mb_strtolower($row['name']) . '"
              data-price="' . $row['price'] . '"
              data-year="' . $row['year'] . '">
                <form method="POST" action="/add">
                  <img src="' . $row['img'] . '" alt="">
                  <a href="/pages/good.php?id=' . $row['id'] . '"><h2>' . $row['name'] . '</h2></a>
                  <p>Цена: ' . number_format($row['price'], 0, ' ', ' ') . ' р.</p>
                  <input type="submit" value="Добавить в корзину" class="btn">
                </form>
          </div>
        '; // выводим данные
    }
    ?>
  </div>
</main>
<?php
require('../php/footer.php');
?>
<script src="../scripts/filter.js"></script>
<script src="../scripts/sort.js"></script>
</body>

</html>