<?php
require('../php/header.php');
require('../php/connect.php');
?>
<main>
    <h2>Авторизация</h2>
    <div class="container reg-form">
        <form action="../php/auth.php" method="POST">
            <input type="text" name="login" placeholder="Логин" required class="inp">
            <input type="password" name="password" placeholder="Пароль" required class="inp">
            <input type="submit" value="Войти" name="auth" class="btn">
        </form>
    </div>
</main>
<?php
require('../php/footer.php');
?>
</body>

</html>