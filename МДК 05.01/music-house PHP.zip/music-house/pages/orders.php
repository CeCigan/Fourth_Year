<?php
require('../php/header.php');
require('../php/connect.php');
?>
<main>
    <h2>Заказы</h2>
    <div class="requests">
        <!--Заказы пользователя-->
        <div class="requests__body">
            <div class="request">
                <div class="request__head">
                    <h3>Заказ 23134</h3>
                    <button id="del1">Удалить заказ</button>
                </div>
                <p>Статус: Новый</p>
                <p>Количество товаров: 4</p>
            </div>
            <div class="request">
                <div class="request__head">
                    <h3>Заказ 54356</h3>
                </div>
                <p>Статус: Подтверждённый</p>
                <p>Количество товаров: 1</p>
            </div>
            <div class="request">
                <div class="request__head">
                    <h3>Заказ 75354</h3>
                </div>
                <p>Статус: Отклонённый</p>
                <p>Количество товаров: 24</p>
                <h4>Причина отклонения:</h4>
                <p>Слишком много товаров</p>
            </div>
            <div class="request">
                <div class="request__head">
                    <h3>Заказ 75354</h3>
                </div>
                <p>Статус: Отклонённый</p>
                <p>Количество товаров: 24</p>
                <h4>Причина отклонения:</h4>
                <p>Слишком много товаров</p>
            </div>
            <div class="request del">
                <div class="request__head">
                    <h3>Заказ 23134</h3>
                    <button id="del2">Удалить заказ</button>
                </div>
                <p>Статус: Новый</p>
                <p>Количество товаров: 4</p>
            </div>
            <div class="request">
                <div class="request__head">
                    <h3>Заказ 54356</h3>
                </div>
                <p>Статус: Подтверждённый</p>
                <p>Количество товаров: 1</p>
            </div>
        </div>
    </div>
    <div class="requestFull">
        <!--Полная информация о заказе пользователя-->
        <div class="request__head">
            <h2>Заказ 23134</h2>
        </div>
        <div class="request__head">
            <p>Статус: Новый</p>
            <p>Количество товаров: 4</p>
            <p>Общая стоимость: 111 р.</p>
        </div>
        <hr>
        <div class="requestik">
            <div class="request_new">
                <div class="request__head">
                    <h4>Товар 1</h4>
                    <p>400 р.</p>
                </div>
                <div class="request__head">
                    <p>Количество товаров: </p>
                    <p>4</p>
                </div>
            </div>
            <div class="request_new">
                <div class="request__head">
                    <h4>Товар 2</h4>
                    <p>400 р.</p>
                </div>
                <div class="request__head">
                    <p>Количество товаров: </p>
                    <p>4</p>
                </div>
            </div>
            <div class="request_new">
                <div class="request__head">
                    <h4>Товар 3</h4>
                    <p>400 р.</p>
                </div>
                <div class="request__head">
                    <p>Количество товаров: </p>
                    <p>4</p>
                </div>
            </div>
            <div class="request_new">
                <div class="request__head">
                    <h4>Товар 4</h4>
                    <p>400 р.</p>
                </div>
                <div class="request__head">
                    <p>Количество товаров: </p>
                    <p>4</p>
                </div>
            </div>
        </div>
    </div>
</main>
<script src="../scripts/cart.js"></script>
<?php
require('../php/footer.php');
?>
</body>

</html>