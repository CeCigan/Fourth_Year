<?php
require('../php/header.php')
?>
<main>
    <h2>Где нас найти</h2>
    <div class="container contacts">
        <img src="../media/images/map.jpg" alt="">
        <p>ул.Пошехонское шоссе, д.37</p>
        <p>+7(900)38-32-024</p>
        <p>MusicHouse@yandex.ru</p>
    </div>
</main>
<?php
require('../php/footer.php');
?>
</body>

</html>