<?php
require('../php/header.php');
require('../php/connect.php');
?>
<main>
    <h2>Добавление и удаление категорий</h2>
    <div class="container">
        <div class="categories">
            <div class="request__head vert">
                <input type="text" placeholder="Название категории">
                <button>Добавить</button>
            </div>
            <div class="request__head vert">
                <select name="" id="">
                    <option value="">Категории</option>
                </select>
                <button>Удалить</button>
            </div>
        </div>
    </div>
    <div class="container">
        <h2>Добавление товара</h2>
        <input type="text" placeholder="Название">
        <input type="text" placeholder="Цена">
        <input type="text" placeholder="Страна производитель">
        <input type="text" placeholder="Год выпуска">
        <input type="text" placeholder="Модель">
        <input type="text" placeholder="Категория">
        <input type="text" placeholder="Количество на складе">
        <p>Фотография товара</p>
        <button>Выбор файла</button>
        <p>Не выбран ни один файл</p>
        <button>Добавить</button>
    </div>
    <div class="container">
        <h2>Заказы</h2>
        <!--Заказы, которые видит админ-->
        <p>Фильтрация</p>
        <button id="all">Все заказы</button>
        <button id="guitar">Новые</button>
        <button id="string">Подтвержденные</button>
        <button id="synth">Отменённые</button>
    </div>
    <div class="catalog">
            <div class="catalog__item guitar">
                <h4>Заказ 21314</h4>
                <p>Заказчик: Иванов Иван Иванович</p>
                <p>Статус заказа: Новый</p>
                <p>Количество товаров: 4</p>
                <button class="btn">Подтвердить заказ</button>
                <h4>Отменить заказ</h4>
                <input type="text" placeholder="Причина отмены">
                <button class="btn exit">Отменить заказ</button>
            </div>
            <div class="catalog__item string">
                <h4>Заказ 43251</h4>
                <p>Заказчик: Иванов Иван Иванович</p>
                <p>Статус заказа: Подтвержденный</p>
                <p>Количество товаров: 2</p>
            </div>

            <div class="catalog__item synth">
                <p>Заказчик: Иванов Иван Иванович</p>
                <p>Статус заказа: Отменённый</p>
                <p>Количество товаров: 4</p>
                <h4>Причина отмены:</h4>
                <p>Мне не понравилось как ты заказал</p>
            </div>
    </div>
</main>
<script src="../scripts/filter.js"></script>
<?php
require('../php/footer.php');
?>
<script src="../scripts/filter.js"></script>
<script src="../scripts/sort.js"></script>
</body>

</html>