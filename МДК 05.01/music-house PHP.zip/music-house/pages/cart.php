<?php
require('../php/header.php');
require('../php/connect.php');
?>
<main>
    <h2>Корзина</h2>
    <div class="container cart">
          <!--Корзина пользователя-->
          <div class="cart__goods">
          <?php
            $result = $mysqli->query("SELECT * FROM `catalog`"); // запрос на выборку
            while ($row = $result->fetch_assoc()) // получаем все строки в цикле по одной
            {
            if($row['id']<4){
            echo
                '
                <div class="catalog__item cart__good ' . $row['type'] . '"
                    data-name="' . mb_strtolower($row['name']) . '"
                    data-price="' . $row['price'] . '"
                    data-year="' . $row['year'] . '">
                    <img src="' . $row['img'] . '" alt="">
                    <a href="/pages/good.php?id=' . $row['id'] . '"><h2>' . $row['name'] . '</h2></a>
                    <p>Цена: ' . '<span class="cost">' . $row['price'] . '</span>' . ' р.</p>
                    <div class="cart__good__btns">
                        <button  class="minus">-</button>
                        <p class="kol">1</p>
                        <button class="plus">+</button>
                    </div>
                    <button class="btn">Убрать из корзины</button>
                </div>
                '; // выводим данные
            }
        }
            ?>
          </div>
          <h3 >Общая стоимость: <span id="priceAll"></span> р.</h3>
          <input type="password" placeholder="Ваш пароль">
          <input type="button" value="Сформировать заказ">
        </div>
</main>
<script src="../scripts/cart.js"></script>
<?php
require('../php/footer.php');
?>
</body>

</html>