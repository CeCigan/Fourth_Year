<?php
require('../php/header.php');
require('../php/connect.php');
?>
<main>
    <?php
    $id = $_GET["id"];
    $result = $mysqli->query("SELECT * FROM `catalog` WHERE `id`=$id"); // запрос на выборку
    while ($row = $result->fetch_assoc()) // получаем все строки в цикле по одной
    {
        echo
        '  
          <div class="good">
            <form class="good__form" method="POST" action="/add">
              <h2>' .$row['name'] . '</h2>
              <img src="' . $row['img'] . '" alt="">
              <p>Год производства: ' . $row['year'] . ' г.</p>
              <p>Страна производитель: ' . $row['country'] . '</p>
              <p>Цена: ' . number_format($row['price'], 0, ' ', ' ') . ' р.</p>
              <input type="submit" value="Добавить в корзину">
            <form>
          </div>
        '; // выводим данные
    }
    ?>
</main>
<?php
require('../php/footer.php');
?>
</body>

</html>