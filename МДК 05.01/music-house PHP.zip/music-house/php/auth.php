<?php
require('connect.php');
session_start();

// Проверяем, если пользователь уже авторизован, перенаправляем на защищенную страницу
if(isset($_SESSION['username'])) {
    header("Location: ../index.php");
    exit;
}

// Обработка формы авторизации
if(isset($_POST['auth'])) {
    $login = $_POST['login'];
    $password = $_POST['password'];

    // Проверяем подключение к базе данных
    if(!$mysqli) {
        die("Ошибка подключения: " . mysqli_connect_error());
    }

    // Защищаемся от SQL-инъекции
    $login = mysqli_real_escape_string($mysqli, $login);
    $password = mysqli_real_escape_string($mysqli, $password);

    // Ищем пользователя в базе данных
    $query = "SELECT * FROM users WHERE login = '$login'";
    $result = mysqli_query($mysqli, $query);

    // Проверяем, найден ли пользователь
    if(mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);

        // Проверяем правильность введенного пароля
        if(md5($password) == $row['password']) {
            // Устанавливаем сессию и перенаправляем на защищенную страницу
            $_SESSION['username'] = $login;
            header("Location: ../index.php");
            exit;
        } else {
            echo "Неверный пароль";
        }
    } else {
        echo "Пользователь не найден";
    }

    // Закрываем подключение к базе данных
    mysqli_close($mysqli);
}
?>