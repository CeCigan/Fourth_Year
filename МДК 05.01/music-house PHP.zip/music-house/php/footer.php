<footer>
      <div class="footer__container">
        <ul>
          <h3>Меню</h3>
          <li><a href="/">О нас</a></li>
          <li><a href="/pages/catalog.php">Каталог</a></li>
          <li><a href="/pages/contacts.php">Где нас найти?</a></li>
        </ul>
      </div>
      <div class="footer__container">
        <ul>
          <h3>Наши соцсети</h3>
          <li><a href="">VK</a></li>
          <li><a href="">Telegram</a></li>
          <li><a href=""></a></li>
        </ul>
      </div>
      <div class="footer__container">
        <ul>
          <h3>Контакты</h3>
          <li>MusicHouse@yandex.ru</li>
          <li>+7(900)38-32-024</li>
        </ul>
      </div>
    </footer>
  </div>