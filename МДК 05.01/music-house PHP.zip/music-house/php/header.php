<?php
session_start(); // открываем сессию
?>
<!DOCTYPE html>
<html lang="ru">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="../styles/style.css" />
    <title>Music House</title>
</head>

<body>
    <div class="wrapper">
        <header>
            <img src="../media/logo-transparent.png" alt="" />
            <ul>
                <li><a href="../index.php">О нас</a></li>
                <li><a href="/pages/contacts.php">Где нас найти?</a></li> 
                <li><a href="/pages/catalog.php">Каталог</a></li>
                <?php
                if(isset($_SESSION['username'])) {
                ?>
                    <li><a href="/pages/cart.php">В корзину</a></li>
                    <li><a href="/pages/orders.php">Заказы</a></li>
                <?php
                if($_SESSION['username'] == 'admin') {
                ?>
                    <li><a href="/pages/admin.php">Админ-панель</a></li>
                <?php
                }
                ?>   
                    <li><a href="/php/quit.php">Выход</a></li>
                <?php
                }
                else if(!isset($_SESSION['username'])){
                ?>
                <li><a href="/pages/login.php">Вход</a></li>
                <li><a href="/pages/reg.php">Регистрация</a></li>
                <?php
                }
                ?>
            </ul>
        </header>