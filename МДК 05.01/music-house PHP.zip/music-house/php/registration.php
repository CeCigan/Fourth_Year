<?php
        require('connect.php');
        if (isset($_POST["surname"]) && isset($_POST["name"]) &&
            isset($_POST["patronymic"]) && isset($_POST["login"]) &&
            isset($_POST["password"]) && isset($_POST["email"])){

            $surname = htmlspecialchars($_POST["surname"]);
            $name = htmlspecialchars($_POST["name"]);
            $patronymic = htmlspecialchars($_POST["patronymic"]);
            $login = htmlspecialchars($_POST["login"]);
            $password = htmlspecialchars(md5($_POST["password"]));
            $email = htmlspecialchars($_POST["email"]);

            $result = $mysqli->query("INSERT INTO `users` (`surname`, `name`, `patronymic`, `login`, `password`, `email`, `role`)
             VALUES ('$surname', '$name', '$patronymic', '$login', '$password', '$email', 0)");

             header('Location:../index.php');
             exit;


        }
?>