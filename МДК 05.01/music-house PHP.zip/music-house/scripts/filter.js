const guitar = document.querySelectorAll('.guitar');
const string = document.querySelectorAll('.string');
const synth = document.querySelectorAll('.synth');

document.getElementById('all').onclick = function () {
    filter('flex', 'flex', 'flex');
}

document.getElementById('guitar').onclick = function () {
    filter('flex', 'none', 'none');
}

document.getElementById('string').onclick = function () {
    filter('none', 'flex', 'none');
}

document.getElementById('synth').onclick = function () {
    filter('none', 'none', 'flex');
}
function filter(a, b, c) {
    for (i = 0; i < guitar.length; i++) {
        guitar[i].style.display = a;
    }
    for (i = 0; i < string.length; i++) {
        string[i].style.display = b;
    }
    for (i = 0; i < synth.length; i++) {
        synth[i].style.display = c;
    }
}