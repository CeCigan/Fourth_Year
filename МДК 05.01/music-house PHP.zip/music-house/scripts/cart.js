// Получаем все карточки товаров
const cartGoods = document.querySelectorAll('.cart__good');

// Функция для увеличения количества товара
function plusVal(event) {
    const card = event.target.closest('.cart__good');
    const quantityElement = card.querySelector('.kol');
    let quantity = parseInt(quantityElement.textContent);
    if (quantity < 20){
      quantity++;
      quantityElement.textContent = quantity;
    }    
}

// Функция для уменьшения количества товара
function minusVal(event) {
    const card = event.target.closest('.cart__good');
    const quantityElement = card.querySelector('.kol');
    let quantity = parseInt(quantityElement.textContent);
    if (quantity > 1) {
        quantity--;
        quantityElement.textContent = quantity;
    }
}

// Функция для удаления товара из корзины
function removeProduct(event) {
  const card = event.target.closest('.cart__good');
  const quantityElement = card.querySelector('.kol');
  const priceElement = card.querySelector('.cost');
  let priceAll = document.getElementById('priceAll');
    
  let quantity = parseInt(quantityElement.textContent);
  const price = parseFloat(priceElement.textContent);
  card.remove(); 
  
  // Обновляем общую цену, вычитая цену удаленных товаров
  let totalPrice = parseFloat(priceAll.textContent);
  totalPrice -= quantity * price;
  
  // Обновляем отображение общей цены
  priceAll.textContent = totalPrice.toFixed(2);
}

// Функция для обновления общей цены
function updateTotalPrice() {
  let priceAll = document.getElementById('priceAll');
  let totalPrice = 0;

  // Перебираем каждую карточку товара
  cartGoods.forEach(card => {
      const quantity = parseInt(card.querySelector('.kol').textContent);
      const price = parseFloat(card.querySelector('.cost').textContent);
      totalPrice += quantity * price;
  });

  // Обновляем отображение общей цены
  priceAll.textContent = totalPrice.toFixed(2); 
}

// Добавляем обработчики событий для кнопок
cartGoods.forEach(card => {
    const plus = card.querySelector('.plus');
    const minus = card.querySelector('.minus');
    const removeButton = card.querySelector('.btn');

    plus.addEventListener('click', plusVal);
    plus.addEventListener('click', updateTotalPrice);
    minus.addEventListener('click', minusVal);
    minus.addEventListener('click', updateTotalPrice);
    removeButton.addEventListener('click', removeProduct);
});

updateTotalPrice();

