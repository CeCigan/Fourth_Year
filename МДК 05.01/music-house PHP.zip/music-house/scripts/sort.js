//получаем кнопки
const filterButtons = document.querySelectorAll('.filterButton');
const sortButtons = document.querySelectorAll('.sortButton');

let catalog = document.querySelector('.catalog');

//Записываем изначальный порядок товаров в массив
const sortStandart = [];
for(let i=0; i<catalog.children.length; i++){
  sortStandart[i] = catalog.children[i];
}

//Сортировка "По умолчанию"
document.querySelector('#sortStandart').onclick = function(){
  mySortStandart();
};

//Сортировка "По году"
document.querySelector('#sortYear').onclick = function(){
  mySort('data-year');
};

//Сортировка "По имени"
document.querySelector('#sortName').onclick = function(){
  mySortName('data-name');
};

//Сортировка "По цене"
document.querySelector('#sortPrice').onclick = function(){
  mySort('data-price');
};

//Функция для сортировки "По умолчанию"
//удаляем все товары и добавляем товары из массива с начальным порядком товаров
function mySortStandart(){
  for(let i=0; i<catalog.children.length; i++){
    for (let j=0; j<catalog.children.length; j++){
    catalog.children[i].outerHTML = '';
    catalog.children[j].outerHTML = '';
   }
  }
  for(let i=0; i<sortStandart.length; i++){
    catalog.appendChild(sortStandart[i]);
  }
}

//Функция для сортировки "По году" и "По цене"
//получаем data-атрибут и заменяем элементы между собой с помощью пузырьковой сортировки
function mySort(sortType){
  for (let i=0; i<catalog.children.length; i++){
    for (let j=i; j<catalog.children.length; j++){
      if (+catalog.children[i].getAttribute(sortType) >
      +catalog.children[j].getAttribute(sortType)){
        replaceNode = catalog.replaceChild(catalog.children[j], catalog.children[i]);
        insertAfter(replaceNode, catalog.children[i]);
      }
    }
  }
}

//Функция для сортировки "По имени"
//получаем data-атрибут и заменяем элементы между собой с помощью пузырьковой сортировки, но первые две буквы строкпи переводятся число
function mySortName(sortType){
  for (let i=0; i<catalog.children.length; i++){
    for (let j=i; j<catalog.children.length; j++){
      if (+parseInt(catalog.children[i].getAttribute(sortType).substring(0,2),36)-9 >
      +parseInt(catalog.children[j].getAttribute(sortType).substring(0,2),36)-9){
        replaceNode = catalog.replaceChild(catalog.children[j], catalog.children[i]);
        insertAfter(replaceNode, catalog.children[i]);
      } 
   } 
  }
}

//Вспомогательная функция для сортировки
function insertAfter(elem, refElem){
  return refElem.parentNode.insertBefore(elem, refElem.nextSibling);
}

