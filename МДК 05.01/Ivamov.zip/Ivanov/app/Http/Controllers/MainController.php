<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Users;

class MainController extends Controller
{
    public function main()
    {
        return view('main');
    }
    public function create()
    {
        return view('registration');
    }
    public function store(Request $req)
    {
        //dd($req->all());
        $userName = $req->faName." ".$req->name." ".$req->otName;
        $user = Users::create([
            'name' => $userName,
            'namber' => $req->namber,
            'email' => $req->email,
            'login' => $req->login,
            'password' => $req->password,
        ]);

    }
}
