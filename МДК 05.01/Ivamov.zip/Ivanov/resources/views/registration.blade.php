<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Laravel</title>
    <link rel="stylesheet" href="{{ asset('/css/style.css') }}">
</head>

<body>
    <h1>Регистрация</h1>
    <form action="/register" method="post" novalidate>
        <div class="form">
            @csrf
            <input type="text" name="login" placeholder="Login" required></input>
            <input type="text" name="password" placeholder="Paassword" required></input>
            <input type="text" name="namber" placeholder="Ноиер телефона" required></input>
            <input type="text" name="faName" placeholder="Фамилия" required></input>
            <input type="text" name="name" placeholder="Имя" required></input>
            <input type="text" name="otName" placeholder="Отчество" required></input>
            <input type="email" name="email" placeholder="Почта" required></input>
            <input type="submit">
        </div>
    </form>
</body>

</html>
