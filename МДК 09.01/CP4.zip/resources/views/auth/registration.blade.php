@include('layouts.header')
  <!-- Форма регистрации -->
  <div class="" id=''>
    <form action="" id="form" method="POST"
    class="lg:w-4/12 my-10 w-8/12 m-auto left-2/4 top-2/4 p-3 bg-gray-200 flex flex-col border-2 rounded-md"
    action="{{route('registration')}}">
    @csrf
      <h2 class="text-center font-semibold text-lg">Регистрация</h2>

      <input type="text" name='username' id="name" autofocus placeholder="Как к вам обращаться?" />
      @error('username')
      <div class="alert alert-error text-base mb-3" id = 'error-report'>
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" 
        class="stroke-current shrink-0 h-6 w-6">
            <path stroke-linecap="round" stroke-linejoin="round" d="M12 9v3.75m9-.75a9 9 0 11-18 0 9 9 0 0118 0zm-9 3.75h.008v.008H12v-.008z" />
        </svg>
        <span>{{$message}}</span>
      </div>
      @enderror
      
      {{-- class="{{$errors->has('username') ? 'input input-bordered input-primary  max-w-xs' : 'input input-bordered input-error max-w-xs'}}" --}}

      <input type="email" name='email' id="email" placeholder="Ваш email"  />
      @error('email')
      <div class="alert alert-error text-base mb-3" id = 'error-report'>
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" 
        class="stroke-current shrink-0 h-6 w-6">
            <path stroke-linecap="round" stroke-linejoin="round" d="M12 9v3.75m9-.75a9 9 0 11-18 0 9 9 0 0118 0zm-9 3.75h.008v.008H12v-.008z" />
        </svg>
        <span>{{$message}}</span>
      </div>
      @enderror

      <input type="password" name='password' id="password" placeholder="Пароль" />
      @error('password')
      <div class="alert alert-error text-base mb-3" id = 'error-report'>
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" 
        class="stroke-current shrink-0 h-6 w-6">
            <path stroke-linecap="round" stroke-linejoin="round" d="M12 9v3.75m9-.75a9 9 0 11-18 0 9 9 0 0118 0zm-9 3.75h.008v.008H12v-.008z" />
        </svg>
        <span>{{$message}}</span>
      </div>
      @enderror
      <input type="password" name = 'password_confirmation' id="passwordCheck" placeholder="Пароль еще раз" /><br />
      @error('password_confirmation')
      <div class="alert alert-error text-base mb-3" id = 'error-report'>
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" 
        class="stroke-current shrink-0 h-6 w-6">
            <path stroke-linecap="round" stroke-linejoin="round" d="M12 9v3.75m9-.75a9 9 0 11-18 0 9 9 0 0118 0zm-9 3.75h.008v.008H12v-.008z" />
        </svg>
        <span>{{$message}}</span>
      </div>
      @enderror

      <input type="submit" id="submit" value="Регистрация" class="lg:h-12 mt-3 m-auto text-center justify-center h-20 text-xl
                    font-normal tracking-wide bg-green-700 text-white transition duration-200 rounded shadow-md
                    hover:bg-green-500 focus:shadow-lg focus:outline-none cursor-pointer" />
    </form>
  </div>
</main>