@include('layouts.header')

<!-- Главная -->
<main class="w-8/12 m-auto flex flex-col justify-center z-0">
    <!-- Секция с калькулятором -->
    <div class="flex flex-col items-center">
       <div class="mt-10 diet-calculator">
           <!-- Поле выбора диеты -->
           <ul class="max-w-[81%] select-diet flex flex-col items-center w-max justify-between border border-[#ebebebaa] 
           rounded-2xl shadow-slate-300 shadow-lg select-none text-2xl lg:text-lg lg:flex-row"
           style="margin: 0 auto;">
               <li class="diet" id = 'diet-btn' onclick="changeCol(1);">
                   <p>Всеядная</p>
                   <img src="{{asset('../resources/images/anythind-diet.png')}}" alt="anything-diet">
               </li>
               <li class="diet" id = 'diet-btn' onclick="changeCol(2);">
                   <p>Палео</p>
                   <img src="{{asset('../resources/images/paleo-diet.png')}}" alt="paleo-diet">
               </li>
               <li class="diet" id = 'diet-btn' onclick="changeCol(3);">
                   <p>Вегетарианская</p>
                   <img src="{{asset('../resources/images/vegetarian-diet.png')}}" alt="vagetarian-diet">
               </li>
               <li class="diet" id = 'diet-btn' onclick="changeCol(4);">
                   <p>Веганская</p>
                   <img src="{{asset('../resources/images/vegan-diet.png')}}" alt="vagan-diet">
               </li>
               <li class="diet" id = 'diet-btn' onclick="changeCol(5);">
                   <p>Кетогенная</p>
                   <img src="{{asset('../resources/images/ketogenic-diet.png')}}" alt="vagan-diet">
               </li>
               <li class="diet" id = 'diet-btn' onclick="changeCol(6);">
                   <p>Средизиноморская</p>
                   <img src="{{asset('../resources/images/mediterranean-diet.png')}}" alt="middlearea-diet">
               </li>
           </ul>
       </div>

       <!-- Калькулятор -->
       <div class="calculator">
           <form action="" class="text-xl">
               <div class="alert alert-error text-base hidden" id = 'error-report'>
                   <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" 
                   class="stroke-current shrink-0 h-6 w-6">
                       <path stroke-linecap="round" stroke-linejoin="round" d="M12 9v3.75m9-.75a9 9 0 11-18 0 9 9 0 0118 0zm-9 3.75h.008v.008H12v-.008z" />
                   </svg>
                   <span>Error! Значение должно быть от 1500 до 8000 ккалорий.</span>
               </div>
               <table class="w-full    ">
                   <!-- Выбор количества калорий -->
                   <div class="my-3 text-center text-sm text-red-500" id = "alert"></div>
                   <tr>
                       <td>
                           <label for="kkals" class="mr-12">На сегодня мне нужно</label>
                       </td>
                       <td>
                           <input type="number"name="kkals" id="kkalsInput" placeholder="#### Килокалорий" 
                                  class="border-green-700 input input-bordered input-primary w-full max-w-xs h-8" />
                       </td>
                   </tr>

                   <!-- Выбор количества блюд -->
                   <tr class="">
                       <td>
                           <label for="count">В количестве</label>
                       </td>
                       <td>
                           <select type="number" name="count" id="foodCount" placeholder="1 блюда"
                                   class="border-green-700 select select-primary w-full max-w-xs">
                               <option value="1">1 блюда</option>
                               <option value="2">2 блюда</option>
                               <option value="3">3 блюда</option>
                               <option value="4">4 блюда</option>    
                               <option value="5">5 блюда</option>
                           </select>
                       </td>
                   </tr>
                   <tr class="w-full text-center mt-4
                   lg:flex-row">
                       <td rowspan="4" colspan="2">
                           <input type ='button' 
                           value="Сгенирировать" 
                           class="button"
                           style=""
                           onclick="getFoods();">
                       </td>
                   </tr>
               </table>
           </form>
       </div>
    </div>
   

   <!-- Панель управления результатами -->
   <div class="result-box hidden"  id = 'food-cards'>
       <div class="flex items-center">
           <div class="mr-4 p-3 border rounded-s-md" id = 'kkalsPlan'></div>
           <div>
               <button class="p-2 flex items-center border rounded-md hover:bg-gray-50">
                   <p class="mr-2 cursor-pointer">Подобрать еще</p>
                   <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
                       <path stroke-linecap="round" stroke-linejoin="round" d="M16.023 9.348h4.992v-.001M2.985 19.644v-4.992m0 0h4.992m-4.993 0l3.181 3.183a8.25 8.25 0 0013.803-3.7M4.031 9.865a8.25 8.25 0 0113.803-3.7l3.181 3.182m0-4.991v4.99" />
                   </svg>                          
               </button>
           </div>
       </div>

       <!-- Див с выдачей результата -->
       <div class="flex mt-5">
           <div class="dish-stats flex">
               
           </div>
           <div class="dishs-reco">
               <p class="dish-header">Завтрак</p>
               <div>
                   <div class="dish-counter dish-shadow" id = 'dish1' onclick="showDishInfo(1);">
                       <div class="avatar dish-pic-zoom">
                           <div class="w-24 rounded">
                             <img src="{{asset('../resorces/images/Vegetable_Plov.jpg')}}" alt="food-pic.jpg"/>
                           </div>
                       </div>
                       <p>Рис с овощами</p>
                       <div class="lg:tooltip flex justify-center items-center w-10 h-10 active:h-16 active:w-16 transition-all" data-tip="Добавить к себе">
                           <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" 
                               class="fill-green-700 hover:fill-green-600 cursor-pointer">
                               <path d="M11.645 20.91l-.007-.003-.022-.012a15.247 15.247 0 01-.383-.218 25.18 25.18 0 01-4.244-3.17C4.688 15.36 2.25 12.174 2.25 8.25 2.25 5.322 4.714 3 7.688 3A5.5 5.5 0 0112 5.052 5.5 5.5 0 0116.313 3c2.973 0 5.437 2.322 5.437 5.25 0 3.925-2.438 7.111-4.739 9.256a25.175 25.175 0 01-4.244 3.17 15.247 15.247 0 01-.383.219l-.022.012-.007.004-.003.001a.752.752 0 01-.704 0l-.003-.001z" />
                           </svg> 
                       </div>                        
                   </div>
                   <!-- Информация о блюде (скрытая) -->
                   <div id="dishInfo1" class="hidden">
                       <!-- Сепаратор -->
                       <div class="ml-7 border-t-2"></div>

                       <!-- Блок с подробной информацией о блюде -->
                       <div class="dish-info" id="food-card-info">
                           <p class="food-name font-semibold text-lg" id = 'name'>Рис с овощами</p>
                           <p class="cook-time text-lg" id = 'cook-time'>30 минут готовки</p>
                           <div class="mt-1 mb-2 border-b-2 border-dotted"></div>
                           <p class="mt-1">В одном блюде:</p>
                           <div class=" flex justify-between" id = 'kkals'>    
                               <p class="text-lg text-emerald-400">Калории</p>
                               <p class="text-lg">193.6</p>
                           </div>
                           <div class="flex justify-between text-violet-400" id = 'uglevods'>
                               <p class="text-lg">Углеводы</p>
                               <p class="text-lg">193.6</p>
                           </div>
                           <div class="flex justify-between text-orange-400" id = 'shiri'>
                               <p class="text-lg">Жиры</p>
                               <p class="text-lg">193.6</p>
                           </div>
                       </div>
                   </div>
                   
                   <div class="dish-counter dish-shadow">
                       <div class="avatar dish-pic-zoom">
                           <div class="w-24 rounded">
                             <img src="images/chiken_with_lemon.jpg" alt="food-pic.jpg"/>
                           </div>
                       </div>
                       <p>Жаренная курочка с лимоном и зеленью</p>
                       <div class="lg:tooltip flex justify-center items-center ww-10 h-10 active:h-16 active:w-16 transition-all" data-tip="Добавить к себе">
                           <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" 
                               class="fill-green-700 hover:fill-green-600 cursor-pointer">
                               <path d="M11.645 20.91l-.007-.003-.022-.012a15.247 15.247 0 01-.383-.218 25.18 25.18 0 01-4.244-3.17C4.688 15.36 2.25 12.174 2.25 8.25 2.25 5.322 4.714 3 7.688 3A5.5 5.5 0 0112 5.052 5.5 5.5 0 0116.313 3c2.973 0 5.437 2.322 5.437 5.25 0 3.925-2.438 7.111-4.739 9.256a25.175 25.175 0 01-4.244 3.17 15.247 15.247 0 01-.383.219l-.022.012-.007.004-.003.001a.752.752 0 01-.704 0l-.003-.001z" />
                           </svg> 
                       </div>                        
                   </div>
               </div>


               <div class="dishs-reco">
                   <p class="dish-header">Завтрак</p>
                   <div>
                       <div class="dish-counter dish-shadow">
                           <div class="avatar dish-pic-zoom">
                               <div class="w-24 rounded">
                                 <img src="images/chiken_with_lemon.jpg" alt="food-pic.jpg"/>
                               </div>
                           </div>
                           <p>Жаренная курочка с лимоном и зеленью</p>
                           <div class="lg:tooltip flex justify-center items-center w-10 h-10 active:h-16 active:w-16 transition-all" data-tip="Добавить к себе">
                               <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" 
                                   class="fill-green-700 hover:fill-green-600 cursor-pointer">
                                   <path d="M11.645 20.91l-.007-.003-.022-.012a15.247 15.247 0 01-.383-.218 25.18 25.18 0 01-4.244-3.17C4.688 15.36 2.25 12.174 2.25 8.25 2.25 5.322 4.714 3 7.688 3A5.5 5.5 0 0112 5.052 5.5 5.5 0 0116.313 3c2.973 0 5.437 2.322 5.437 5.25 0 3.925-2.438 7.111-4.739 9.256a25.175 25.175 0 01-4.244 3.17 15.247 15.247 0 01-.383.219l-.022.012-.007.004-.003.001a.752.752 0 01-.704 0l-.003-.001z" />
                               </svg> 
                           </div>                        
                       </div>
                       <div class="dish-counter dish-shadow">
                           <div class="avatar dish-pic-zoom">
                               <div class="w-24 rounded">
                                 <img src="images/chiken_with_lemon.jpg" alt="food-pic.jpg"/>
                               </div>
                           </div>
                           <p>Жаренная курочка с лимоном и зеленью</p>
                           <div class="lg:tooltip flex justify-center items-center w-10 h-10 active:h-16 active:w-16 transition-all" data-tip="Добавить к себе">
                               <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" 
                                   class="fill-green-700 hover:fill-green-600 cursor-pointer">
                                   <path d="M11.645 20.91l-.007-.003-.022-.012a15.247 15.247 0 01-.383-.218 25.18 25.18 0 01-4.244-3.17C4.688 15.36 2.25 12.174 2.25 8.25 2.25 5.322 4.714 3 7.688 3A5.5 5.5 0 0112 5.052 5.5 5.5 0 0116.313 3c2.973 0 5.437 2.322 5.437 5.25 0 3.925-2.438 7.111-4.739 9.256a25.175 25.175 0 01-4.244 3.17 15.247 15.247 0 01-.383.219l-.022.012-.007.004-.003.001a.752.752 0 01-.704 0l-.003-.001z" />
                               </svg> 
                           </div>                        
                       </div>
                   </div>
               </div>  
           </div>
       </div>
   </div>

   <!-- Преимущества -->
   <div class="lg:w-[80vw] w-full mt-10 mb-10 m-auto advantages ">
       <p class="lg:text-xl font-bold text-2xl text-center mb-10 flex justify-around">Создайте свой рацион питания за 5 минут</p>
       <div class="advantages-cards-group flex justify-between flex-wrap">
           <div class="advantages-card w-2/4 flex flex-col items-center">
               <img src="{{asset('../resources/images/buy-food.png')}}" alt="" class="w-22">
               <b class="text-center">Придерживайтесь любого стиля питания или создайте свой </b>
               <p class="text-center"> Вы можете настроить популярные стили питания, такие как веганский и палео, в соответствии со своими потребностями и предпочтениями.</p>
           </div>

           <div class="advantages-card w-2/4 flex flex-col items-center">
               <img src="{{asset('../resources/images/axiety.png')}}" alt="" class="w-24">
               <b class="text-center">Избавьте себя от беспокойства с 
                   выбором, чего вам съесть</b>
               <p class="text-center"> Принимайте важные решения заранее и по собственному графику. Тогда не о чем беспокоиться, когда придет время есть.</p>
           </div>
           <div class="advantages-card w-2/4 m-auto h-fit flex flex-col items-center">
               <img src="{{asset('../resources/images/fredge.png')}}" alt="" class="w-24">
               <b class="text-center">Увеличьте место в своем холодильнике </b>
               <p class="text-center"> Заблаговременное планирование означает, что меньше продуктов портятся в холодильнике. 
                   Добавьте то, что у вас уже есть, в виртуальную кладовую, и наши алгоритмы будут использовать это в приоритетном порядке.
               </p>
           </div>
       </div>
   </div>

   <!-- Отзывы о нас -->
   <div class="reviews">
       <div class="review flex flex-row justify-stretch">
           <img src="{{asset('../resources/images/before-after-1.jpg')}}" alt="before-after">
           <p class="text-green-300 review-text"> — “Когда-то я делал летсплеи по майнкрафту, но потом 
               я записался в качалку. Мои характеристики были 150 / 114. 
               Благодаря этому сайту я смог составить свой рацион, 
               начать эффективно заниматься и похудеть на 60 килограмм за 1.5 года
               Позже я завёл ручного хомяка Семёна, спасибо!!!” 
           </p>
       </div>
       <p class="mt-2 text-white">Владимир Мухбар<br>
           Фотомодель журнала "SemenO"</p>

       <div class="review mt-10 flex flex-row justify-stretch">
           <p class="text-green-300 review-text"> — “Когда-то я делал летсплеи по майнкрафту, но потом 
               я записался в качалку. Мои характеристики были 150 / 114. 
               Благодаря этому сайту я смог составить свой рацион, 
               начать эффективно заниматься и похудеть на 60 килограмм за 1.5 года
               Позже я завёл ручного хомяка Семёна, спасибо!!!” 
           </p>
           <img src="{{asset('../resources/images/before-after-2.jpg')}}" alt="before-aftet">
       </div>
        <p class="mt-2 text-white float-right w-72">Максим Сельков<br>
           Региональный чемпион по тяжелой атлетике</p>
       <button class="mt-10">Начать бесплатно</button>
   </div>   
</main>
@include('layouts.footer')
