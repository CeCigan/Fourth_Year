<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="{{asset('../resources/css/style.css')}}">
    {{-- @vite('resources/css/style.css')
    @vite('resources/css/style.css') --}}
    <title>Здоровая еда.рф - Главная страница</title>
</head>
<body>
<div class=" m-auto lg:w-8/12 w-10/12 bg-green-700 z-10 rounded-ee-xl rounded-es-xl pt-2 pb-4" id = 'header'>
    <div class="lg:flex items-center h-20 w-11/12 m-auto inline-block justify-around header">
        <header class="mb-5 flex justify-center items-center w-full">
            <img src="{{url('../')}}/resources/images/salad.ico" class="w-auto lg:h-10 h-20" alt="logo">
            <p class="lg:text-2xl text-xl h-10 ml-3 flex items-center font-semibold text-green-300">Здорово Питаться.рф</p>
        </header>
        <!-- Кнопки навигации -->
        <div class="ml-7 w-full flex justify-evenly">
            <a href = "{{route('main')}}" class="flex items-center nav-btn transition duration-200 w-fit">
                <p class="hidden lg:block">Главная</p>
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" 
                    class="w-8 h-8 block lg:hidden">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M2.25 12l8.954-8.955c.44-.439 1.152-.439 1.591 0L21.75 12M4.5 9.75v10.125c0 .621.504 1.125 1.125 1.125H9.75v-4.875c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125V21h4.125c.621 0 1.125-.504 1.125-1.125V9.75M8.25 21h8.25" />
                  </svg>                      
            </a>
            <a href="{{route('diets')}}" class="flex items-center nav-btn transition duration-200 w-fit">
                <p class="hidden lg:block">Каталог блюд</p>
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" 
                    class="w-8 h-8 block lg:hidden">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M12 8.25v-1.5m0 1.5c-1.355 0-2.697.056-4.024.166C6.845 8.51 6 9.473 6 10.608v2.513m6-4.87c1.355 0 2.697.055 4.024.165C17.155 8.51 18 9.473 18 10.608v2.513m-3-4.87v-1.5m-6 1.5v-1.5m12 9.75l-1.5.75a3.354 3.354 0 01-3 0 3.354 3.354 0 00-3 0 3.354 3.354 0 01-3 0 3.354 3.354 0 00-3 0 3.354 3.354 0 01-3 0L3 16.5m15-3.38a48.474 48.474 0 00-6-.37c-2.032 0-4.034.125-6 .37m12 0c.39.049.777.102 1.163.16 1.07.16 1.837 1.094 1.837 2.175v5.17c0 .62-.504 1.124-1.125 1.124H4.125A1.125 1.125 0 013 20.625v-5.17c0-1.08.768-2.014 1.837-2.174A47.78 47.78 0 016 13.12M12.265 3.11a.375.375 0 11-.53 0L12 2.845l.265.265zm-3 0a.375.375 0 11-.53 0L9 2.845l.265.265zm6 0a.375.375 0 11-.53 0L15 2.845l.265.265z" />
                  </svg>
            </a>
                @auth()
                    <a href="{{route('admin')}}" class="flex items-center nav-btn transition duration-200 w-fit">
                        <p class="hidden lg:block">Админ-панель</p>
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="lg:hidden block w-8 h-8">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M21.75 6.75a4.5 4.5 0 01-4.884 4.484c-1.076-.091-2.264.071-2.95.904l-7.152 8.684a2.548 2.548 0 11-3.586-3.586l8.684-7.152c.833-.686.995-1.874.904-2.95a4.5 4.5 0 016.336-4.486l-3.276 3.276a3.004 3.004 0 002.25 2.25l3.276-3.276c.256.565.398 1.192.398 1.852z" />
                            <path stroke-linecap="round" stroke-linejoin="round" d="M4.867 19.125h.008v.008h-.008v-.008z" />
                        </svg>                      
                    </a>
                @endauth
            @if (Auth::check())
                <a href = "{{route('logout')}}" class="flex items-center nav-btn transition duration-200 w-fit">      
                    <p class="hidden lg:block">Выйти</p>
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"
                        class="w-8 h-8 block lg:hidden">   
                        <path stroke-linecap="round" stroke-linejoin="round" d="M15.75 9V5.25A2.25 2.25 0 0013.5 3h-6a2.25 2.25 0 00-2.25 2.25v13.5A2.25 2.25 0 007.5 21h6a2.25 2.25 0 002.25-2.25V15m3 0l3-3m0 0l-3-3m3 3H9" />
                      </svg>  
                </a>
            @endif
            @guest
                <a href = "{{route('registration')}}" class="flex items-center nav-btn transition duration-200 w-fit">
                    <p class="hidden lg:block">Зарегистрироваться</p>
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" 
                        class="w-8 h-8 block lg:hidden">   
                        <path stroke-linecap="round" stroke-linejoin="round" d="M19 7.5v3m0 0v3m0-3h3m-3 0h-3m-2.25-4.125a3.375 3.375 0 11-6.75 0 3.375 3.375 0 016.75 0zM4 19.235v-.11a6.375 6.375 0 0112.75 0v.109A12.318 12.318 0 0110.374 21c-2.331 0-4.512-.645-6.374-1.766z" />
                    </svg>
                </a>
                <a href = "{{route('login')}}" class="flex items-center nav-btn transition duration-200 w-fit">
                    <p class="hidden lg:block">Войти</p>
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"
                        class="w-8 h-8 block lg:hidden">   
                        <path stroke-linecap="round" stroke-linejoin="round" d="M15.75 5.25a3 3 0 013 3m3 0a6 6 0 01-7.029 5.912c-.563-.097-1.159.026-1.563.43L10.5 17.25H8.25v2.25H6v2.25H2.25v-2.818c0-.597.237-1.17.659-1.591l6.499-6.499c.404-.404.527-1 .43-1.563A6 6 0 1121.75 8.25z" />
                    </svg>                  
                </a>
            @endguest
        </div>
    </div>
</div>

