let activeButton = null, // Переменная для хранения активной кнопки
    activeInfo = null; //Перемнная хранения активной формы

function changeCol(id) {
  let button = document.querySelectorAll('#diet-btn')[id - 1];
  
  if (activeButton === button) {
    // Если кнопка уже активна, возвращаем исходный фон
    button.classList.remove('active');
    activeButton = null;
  } else {
    // Если кнопка не активна, обновляем фон и сохраняем кнопку в переменную
    if (activeButton) {
      activeButton.classList.remove('active');
    }
    button.classList.add('active');
    activeButton = button;
  }
}
/**
 * Скрывает и показывает информацию о блюде
 * Входящие данные - id блюда
 */
function showDishInfo(id){
  let dish = document.getElementById('dish'+id);
  let item = document.getElementById('dishInfo'+id);

  if(activeInfo === dish){
    item.classList.add ('hidden');
    activeInfo = null;
  } else {
    if(activeInfo){
      activeInfo.classList.add('hidden');
    }
    item.classList.remove('hidden');
    activeInfo = dish;
  }
  console.log(id);
}