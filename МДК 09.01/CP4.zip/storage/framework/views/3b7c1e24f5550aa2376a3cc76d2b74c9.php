<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Форма Входа -->
<main>
    <div class="w-full">
        <form id="form" method="POST" 
        class="lg:w-4/12 my-10 w-8/12 m-auto left-2/4 top-2/4 p-3 bg-gray-200 flex flex-col border-2 rounded-md z-10"
        action="<?php echo e(route('login')); ?>"
        >
          <?php echo csrf_field(); ?>  
          <h2 class="text-center font-semibold text-lg">Вход</h2>

          <?php $__errorArgs = ['loginError'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert alert-error text-base" id = 'error-report'>
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" 
              class="stroke-current shrink-0 h-6 w-6">
                  <path stroke-linecap="round" stroke-linejoin="round" d="M12 9v3.75m9-.75a9 9 0 11-18 0 9 9 0 0118 0zm-9 3.75h.008v.008H12v-.008z" />
              </svg>
              <span><?php echo e($message); ?></span>
            </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                
            <input type="email" id="surname" placeholder="Ваш email" autofocus required />
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert alert-error text-base" id = 'error-report'>
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" 
              class="stroke-current shrink-0 h-6 w-6">
                  <path stroke-linecap="round" stroke-linejoin="round" d="M12 9v3.75m9-.75a9 9 0 11-18 0 9 9 0 0118 0zm-9 3.75h.008v.008H12v-.008z" />
              </svg>
              <span><?php echo e($message); ?></span>
            </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <input type="password" id="password" placeholder="Пароль" required />
            <input
              type="password"
              id="passwordCheck"
              placeholder="Пароль еще раз"
              required
              onchange="validate();"
            /><br />
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert alert-error text-base px-10" id = 'error-report'>
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" 
              class="stroke-current shrink-0 h-6 w-6">
                  <path stroke-linecap="round" stroke-linejoin="round" d="M12 9v3.75m9-.75a9 9 0 11-18 0 9 9 0 0118 0zm-9 3.75h.008v.008H12v-.008z" />
              </svg>
              <span><?php echo e($message); ?></span>
            </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <div class="form-control w-fit m-auto items-center">
              <label class="label cursor-pointer">
                <span class="label-text text-lg">Запомните меня</span> 
                <input type="checkbox" checked="checked" class="checkbox checkbox-primary checkbox-lg" />
              </label>
            </div>
      
            <input type="submit" 
            id="submit" 
            value="Войти" 
            class="lg:h-9 mt-3 m-auto text-center justify-center h-16 text-xl w-full
                    font-normal tracking-wide bg-green-700 text-white transition duration-200 rounded shadow-md
                    hover:bg-green-500 focus:shadow-lg focus:outline-none cursor-pointer"/>
        </form>
      </div> 
</main><?php /**PATH W:\domains\course-work\resources\views/auth/login.blade.php ENDPATH**/ ?>