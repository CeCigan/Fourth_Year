<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
<!-- Главная -->
<main class="lg:w-8/12 w-full m-auto flex flex-col justify-center z-0">
    <h4 class="header font-black">Приветствуем,</h4>
    <div class="">
        <section class="">
            <h4 class="pl-16">Ваши любимые блюда:</h4>
            <div class="users-dishs">
                <div class="card w-auto max-w-[60vw] md:max-w-[25vw] bg-base-100 shadow-xl">
                    <figure><img src = "./images/chiken_with_lemon.jpg" alt="Food" loading="lazy"/></figure>
                    <div class="card-body">
                        <h2 class="card-title">Курочка с лимоном</h2>
                        <p class="card-normal">На 100 грамм:</p>
                        <div class="card-actions justify-center">
                        <div class="radial-progress text-primary" style="--value:0; --value:21; --size:7rem; --thickness: 4px;">Белки: 21гр</div>
                        <div class="radial-progress text-secondary" style="--value:0; --value:30; --size:7rem; --thickness: 4px;">Жиры: 30гр</div>  
                        <div class="radial-progress text-accent" style="--value:0; --value:48; --size:7rem; --thickness: 4px;">Углв: 48гр</div>  
                    </div>
                    </div>
                </div>
            </div>

            <div class="day-food-info">
                <div class="">
                    <h3>Каллорий за день</h3>
                </div>
            </div>
        </section>
    </div>
</main> 
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;<?php /**PATH W:\domains\course-work\resources\views/user-page.blade.php ENDPATH**/ ?>