<?php

use App\Http\Controllers\AdminController;
use App\Http\Controllers\UserPageController;
use GuzzleHttp\Middleware;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ContentController;
use App\Http\Middleware\Authenticate;
use App\Http\Controllers\RegisterController;
use App\Http\Controllers\LoginController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

// Роутинг переключения страниц:
Route::get('/', function () {
    return view('main');
})->name('main');

Route::get('/diets', [ContentController::class, 'loadFoods'])->name('diets');

Route::get('/register', [RegisterController::class, 'showPage'])->middleware('guest')->name('registration');
Route::post('/register', [RegisterController::class, 'register'])->middleware('guest');

Route::get('/login', [LoginController::class, 'showPage'])->middleware('guest')->name('login');
Route::post('/login', [LoginController::class, 'login'])->middleware('guest');

// //Роутинг загрузки контента
// Route::get('/diets', [ContentController::class, 'loadFoods'])->name('diets');

// // Руты Регистрации
Route::view('/user-page', 'user-page')->middleware('auth')->name('user-page');

Route::get('/logout', function () {
    Auth::logout();
    return redirect('/');
})->name('logout');

// Route::group(['middleware' => ['auth', 'admin']], function () {
// });

Route::group(['prefix' => 'admin', 'middleware' => 'admin', 'as' => 'admin.'], function () {
    Route::get('/admin', [AdminController::class, 'showPage'])->name('admin');
});

