<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     */

    //id (primary key) username (имя пользователя) email (адрес электронной почты) password (хешированный пароль) Другие поля по необходимости (имя, фамилия, возраст и т. д.)
    public function up(): void
    {
        Schema::create('Users', function (Blueprint $table) {
            $table->id();
            $table->char('username', 255);
            $table->char('email', 255)->nullable(false)->unique('email');
            $table->char('password', 100)->nullable(false);
            $table->char('remember_token', 100)->nullable(true);
            $table->boolean('isAdmin')->default(false);
            $table->unsignedBigInteger('id_recipe');
            $table->timestamps();

            $table->foreign('id_recipe')->references('id')->on('Recipes');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('Users');
    }
};