/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./resources/**/*.blade.php",
    "./resources/**/**/*.blade.php",
  ],
  theme: {
    extend: {},
  },
  plugins: [require("daisyui")],
  daisyui: {
    themes: [
      {
        main: {
        "primary": "#157f3c",
        "secondary": "#16a34a",
        "accent": "#fb923c",
        "neutral": "#6b7280",
        "base-100": "#f3f4f6",
        "info": "#3abff8",
        "success": "#36d399",
        "warning": "#fbbd23",        
        "error": "#f87272",
        },
      },
    ],
  },
}

