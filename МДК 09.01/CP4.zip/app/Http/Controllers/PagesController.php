<?php

namespace App\Http\Controllers;

use App\Models\Users;
use Illuminate\Http\Request;

class AdminController extends Controller
{
    public function showAdminPage()
    {
        $this->authorize('admin-page-component', [self::class]);
        return view('admin');
    }
}
