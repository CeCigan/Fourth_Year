<?php

namespace App\Http\Controllers;

use App\Models\Products;
use Illuminate\Http\Request;

class ContentController extends Controller
{
    function loadFoods()
    {
        $foods = Products::all(); //orderBy('prod_name', 'desc')->paginate(5);

        return view('diets')->with(['foods' => $foods]);
    }
}
