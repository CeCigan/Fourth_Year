<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Redirect;

class LoginController extends Controller
{
    public function showPage()
    {
        return view("auth.login");
    }
    public function login(Request $request)
    {
        if (Auth::check()) {
            return Redirect::intended(route("user-page"));
        }

        $request->only([
            "email" => "required|string|email",
            "password" => "required|string",
        ]);

        if (Auth::attempt($request->only('email', 'password'))) {
            return redirect()->intended(route("user-page"));
        }

        return redirect(route("login"))->withErrors([
            "loginError" => "Не удалось войти в аккаунт"
        ]);

        if (Auth::user()->isAdmin == 1) {
            return redirect('/admin');
        } else {
            return redirect('/');
        }
    }
}
