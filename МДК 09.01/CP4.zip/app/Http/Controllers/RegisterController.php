<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use illuminate\Support\Facades\Auth;
use App\Models\Users;

class RegisterController extends Controller
{
    public function showPage()
    {
        return view("auth.registration");
    }
    public function register(Request $request)
    {
        if (Auth::check()) {
            return redirect(route('user-page'));
        }

        $validateFields = $request->validate([
            "username" => "required|string",
            "email" => "required|string|email|unique:users",
            "password" => "required|confirmed|min:8",
        ]);

        if (Users::where("username", $validateFields["username"])->exists()) {
            return redirect(route("auth.registration"))->withErrors(
                ["email" => trans("Такой пользователь уже существует")]
            );
        }

        $user = Users::create($validateFields);
        if ($user) {
            Auth::login($user);
            return redirect(route('user-page'));
        }
        return redirect(route("auth.login"))->withErrors(
            ["email" => trans("Ошибка при сохранении :(")]
        );
    }
}
